document.addEventListener("DOMContentLoaded", function() {
    console.log("Уйгурско-Динозаворская Война загружена!");
});
